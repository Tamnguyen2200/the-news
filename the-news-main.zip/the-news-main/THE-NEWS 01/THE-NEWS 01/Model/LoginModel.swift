//
//  LoginModel.swift
//  THE-NEWS 01
//
//  Created by TamNguyen on 20/12/2022.
//

import UIKit

struct LoginModel: Encodable {
    let login: String
    let password: String 
}
